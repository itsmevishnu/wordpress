=== htpasswd Generator ===
Contributors: vishnujayadhevan
Tags: widgets, change .htaccess
Requires at least: 3.2
Tested up to: 4.7
Stable tag: 1
License: GPLV-2
License URI: https://www.gnu.org/licenses/old-licenses/gpl-2.0.en.html

.htpasswd Generator Widget

== Description ==
You need to add a widget to help other developers. Here is a nice way to help some web developers.

Editing .htaccess is sometimes a headache to others. Here .htpasswd Generator Widget helps you to add a .htpasswd protected folder with easy
You can easly configure this plugin to your site.

Any comments and suggestion are welcome.
Please mailme *hello@vishnujayan.in*

== Installation ==
1. Download the plugin file
2. Extract file to wp-contents/wp-plugin folder
3. Go to plugin list
4. Install plugin
5. Use shortcode [htpasswd] inside post or page
6. Or you can use widget in any widget area
